/ - login and register screen
/profile - profile page with boards
/feed - feed page with all different pins
/save/:pinid - save pins in a board
/delete/:pinid - delete pins from board
/logout
/register
/login
/edit
/upload